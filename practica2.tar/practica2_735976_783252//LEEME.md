del Rincón de la Villa, Alonso  783252@unizar.es  a783252
Lardiés Getán, Alberto  735976@unizar.es  a735976

---------Pinball-----------

Uso: pinball fichero_parametros fichero_resultados

Descripción: dados unos parámetros de profundidad del árbol y número de bolas escribe en el fichero de resultados los tiempos de construcción del árbol y obtención del nodo hoja donde acaba cada bola.

----------Script ejecutar.sh---------
Descripción: compila el programa anterior y lo ejecuta para distintas combinaciones de los parámetros (descritas en profundidad en la memoria)