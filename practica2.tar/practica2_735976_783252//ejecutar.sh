#!/bin/bash
echo "compilando"
g++ main.cpp -o pinball -std=c++11
echo "pruebas aumentando n de bolas"
./pinball pruebas_bolas.txt resultados_bolas.txt
echo "pruebas aumentando profundidad"
./pinball pruebas_profundidad.txt resultados_profundidad.txt
echo "pruebas aumentando ambos"
./pinball pruebas.txt resultados.txt